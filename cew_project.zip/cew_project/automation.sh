#!/bin/bash


request="/home/sharaf/Desktop/cew_project/request_api/outputs"
details="/home/sharaf/Desktop/cew_project/extract_data/details.sh"
notifications="/home/sharaf/Desktop/cew_project/alerts/alert.sh"
log_file="/home/sharaf/Desktop/cew_project/logs/script.log"

cleanup(){
echo "exiting the program"
exit 0
}
trap cleanup SIGINT   #when you press ctrl+c it cleansup 

#call out the api
$request

#send the aler if temp is unsutaible 
$notifications


#succesfully run the code
echo "======printed to log file successfully=========="




#writes to thelog file
$details >> $log_file


