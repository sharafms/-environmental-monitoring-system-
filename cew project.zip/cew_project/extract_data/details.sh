#!/bin/bash

#check if jq is installed
if ! command -v jq &> /dev/null; then            
 echo "jq is not available in the system"

fi

json_file="/home/sharaf/Desktop/cew_project/request_api/weather_data.json"
details_file="/home/sharaf/Desktop/cew_project/extract_data/details.txt"

#extract details from json file
country=$(jq -r '.sys.country' "$json_file")
city=$(jq -r '.name' "$json_file")
temperature=$(jq -r '.main.temp' "$json_file")
humidity=$(jq -r '.main.humidity' "$json_file")

#this is to display to the user
echo "============================="
echo "Environmental Report - $(date)" 
echo "country: $country"
echo "city: $city" 
echo "Temperature: $temperature °C" 
echo "Humidity: $humidity%" 
echo "==========================="


#write the extract details to details.txt file"
echo "Temperature: $temperature °C at $(date)" >> "$details_file"



