#!/bin/bash

json_file="/home/sharaf/Desktop/cew_project/request_api/weather_data.json"

temperature="$(jq -r '.main.temp' "$json_file")"

thresold_temp_high=30
thresold_temp_low=10
elastic_username="sharaf0720@gmail.com"
elastic_password="71FE64F46668F0911E5902E87DA21001EC46"
from_email="sharaf0720@gmail.com"
to_email="sharaf0720@gmail.com"




 if (( $(echo "$temperature > 30" | bc -l ) )); then
  subject="temperature high"
  body="ALERT the temperature is $temperature which is above the limit"
  sendemail -f "$from_email" \
           -t "$to_email" \
           -u "$subject" \
           -m "$body" \
           -s smtp.elasticemail.com:2525 \
           -o tls=yes \
           -xu "$elastic_username" \
           -xp "$elastic_password"
           
  echo "email sent"
  
 elif (( $(echo "$temperature < 10" | bc -l) )); then
  subject="temperature low"
  body="ALERT the temperature is $temperature which is lower the limit" 
  sendemail -f "$from_email" \
           -t "$to_email" \
           -u "$subject" \
           -m "$body" \
           -s smtp.elasticemail.com:2525 \
           -o tls=yes \
           -xu "$elastic_username" \
           -xp "$elastic_password"
           
  echo "email sent"
  
 else
  subject="temperature is normal"
  body="the temperature is $temperature a perfect day"
  sendemail -f "$from_email" \
           -t "$to_email" \
           -u "$subject" \
           -m "$body" \
           -s smtp.elasticemail.com:2525 \
           -o tls=yes \
           -xu "$elastic_username" \
           -xp "$elastic_password"
           
  echo "email sent"
  echo "temperature is normal"

fi
 
 
